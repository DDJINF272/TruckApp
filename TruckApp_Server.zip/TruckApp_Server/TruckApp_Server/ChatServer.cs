﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Collections;

namespace TruckApp_Server
{
    class ChatServer
    {
        // This hash table stores users and connections(browsable by user)
        public static Hashtable hashUsers = new Hashtable(30); // 30 users at one time limit
        
        
        // This hash table stores connections and users (browsable by connection)
        public static Hashtable hashConnections = new Hashtable(30);
                                                                   
        // Will store the IP address passed to it
        private IPAddress ipAddress;
        private TcpClient tcpClient;



        public ChatServer(IPAddress address)
        {
            ipAddress = address;
        }

        // The thread that will hold the connection listener
        private Thread threadListen;

        // The TCP object that listens for connections
        private TcpListener clientListener;

        // Will tell the while loop to keep monitoring for connections
        bool Running = false;

        // Add the user to the hash tables
        public static void AddUser(TcpClient tcpUser, string strUsername)
        {
            
            ChatServer.hashUsers.Add(strUsername, tcpUser);
            ChatServer.hashConnections.Add(tcpUser, strUsername);

            // Tell of the new connection to all other users
            SendAdminMessage(hashConnections[tcpUser] + " is active");
        }

        
        public static void RemoveUser(TcpClient tcpUser)
        {
            // If the user is there
            if (hashConnections[tcpUser] != null)
            {
                // First show the information and tell the other users about the disconnection
                SendAdminMessage(hashConnections[tcpUser] + " has disconnected");

                // Remove the user from the hash table
                ChatServer.hashUsers.Remove(ChatServer.hashConnections[tcpUser]);
                ChatServer.hashConnections.Remove(tcpUser);
            }
        }

        public static void SendAdminMessage(string Message)
        {
            StreamWriter streamWriter;



            // Create an array of TCP clients
            TcpClient[] tcpClients = new TcpClient[ChatServer.hashUsers.Count];
            
            // Copy the TcpClient objects into the array
            ChatServer.hashUsers.Values.CopyTo(tcpClients, 0);
           
            // Loop through the list of TCP clients
            for (int i = 0; i < tcpClients.Length; i++)
            {
                // Try sending a message to each
                try
                {
                    // If the message is blank or the connection is null, exit
                    if (Message.Trim() == "" || tcpClients[i] == null)
                    {
                        continue;
                    }
                    
                    // Send the message to the current user
                    streamWriter = new StreamWriter(tcpClients[i].GetStream());
                    streamWriter.WriteLine("Server : " + Message);
                    streamWriter.Flush();
                    streamWriter = null;
                }
                catch
                {
                    RemoveUser(tcpClients[i]);
                }
            }
        }

        
    public static void SendMessage(string From, string Message)
        {
            StreamWriter streamWriteToOthers;

            TcpClient[] tcpClients = new TcpClient[ChatServer.hashUsers.Count];
            // Copy the TcpClient objects into the array
            ChatServer.hashUsers.Values.CopyTo(tcpClients, 0);
            // Loop through the list of TCP clients
            for (int i = 0; i < tcpClients.Length; i++)
            {
                // Try sending a message to each
                try
                {
                    
                    if (Message.Trim() == "" || tcpClients[i] == null)
                    {
                        continue;
                    }
                    // Send the message to the current user in the loop
                    streamWriteToOthers = new StreamWriter(tcpClients[i].GetStream());
                    streamWriteToOthers.WriteLine(From + " says: " + Message);
                    streamWriteToOthers.Flush();
                    streamWriteToOthers = null;
                }
                catch
                {
                    RemoveUser(tcpClients[i]);
                }
            }
        }

        public void StartListening()
        {

            // Get the IP of the first network device, however this can prove unreliable on certain configurations
            IPAddress ipaLocal = ipAddress;

            // Create the TCP listener object using the IP of the server and the specified port
            clientListener = new TcpListener(ipAddress,1986);

            // Start the TCP listener and listen for connections
            clientListener.Start();

            // The while loop will check for true in this before checking for connections
            Running = true;

            // Start the new tread that hosts the listener
            threadListen = new Thread(KeepListening);
            threadListen.Start();
        }

        private void KeepListening()
        {
            // While the server is running
            while (Running == true)
            {
                // Accept a pending connection
                tcpClient = clientListener.AcceptTcpClient();
                // Create a new instance of Connection
                Connection newConnection = new Connection(tcpClient);
            }
        }

    }
}
