﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using System.Net;

namespace TruckApp_Server
{
    class Program
    {

        private delegate void UpdateStatusCallback(string strMessage);
        static void Main(string[] args)
        {
             IPAddress ipAddr = IPAddress.Parse("127.0.0.1");
            ChatServer mainServer = new ChatServer(ipAddr);
            mainServer.StartListening();
            Console.WriteLine("Server has started...\r\n");

        }

    }
     
}
