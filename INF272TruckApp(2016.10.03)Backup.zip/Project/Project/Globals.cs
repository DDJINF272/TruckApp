﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class Globals
    {
        public static string DBConn = "Data Source=localhost;Initial Catalog=TruckApp;Integrated Security=True";
    }
}
