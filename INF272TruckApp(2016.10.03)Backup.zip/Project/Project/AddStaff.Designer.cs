﻿namespace Project
{
    partial class AddStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCellphone = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAddressProvince = new System.Windows.Forms.TextBox();
            this.txtCityAddress = new System.Windows.Forms.TextBox();
            this.txtAddressSuburb = new System.Windows.Forms.TextBox();
            this.txtStreetNumber = new System.Windows.Forms.TextBox();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtBranchCode = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtAccountNumber = new System.Windows.Forms.TextBox();
            this.txtAccountType = new System.Windows.Forms.TextBox();
            this.txtBranchName = new System.Windows.Forms.TextBox();
            this.txtBankName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtSumProvince = new System.Windows.Forms.TextBox();
            this.txtSumCity = new System.Windows.Forms.TextBox();
            this.txtSumSuburb = new System.Windows.Forms.TextBox();
            this.txtSumStreetNum = new System.Windows.Forms.TextBox();
            this.txtSumStreet = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtSumBranchCode = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtSumAccountNumber = new System.Windows.Forms.TextBox();
            this.txtSumAccountType = new System.Windows.Forms.TextBox();
            this.txtSumBranchname = new System.Windows.Forms.TextBox();
            this.txtSumBank = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtSumDepartment = new System.Windows.Forms.TextBox();
            this.txtSumDrivers = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSumCellphone = new System.Windows.Forms.TextBox();
            this.txtSumID = new System.Windows.Forms.TextBox();
            this.txtSumLastname = new System.Windows.Forms.TextBox();
            this.txtSumFirstname = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(566, 331);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(558, 305);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Member Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbDepartment);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtCellphone);
            this.groupBox2.Controls.Add(this.txtID);
            this.groupBox2.Controls.Add(this.txtLastname);
            this.groupBox2.Controls.Add(this.txtFirstname);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(6, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 184);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personal Information";
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Location = new System.Drawing.Point(110, 151);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(145, 21);
            this.cmbDepartment.TabIndex = 17;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(33, 154);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "Department  :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(110, 123);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(145, 21);
            this.comboBox1.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 126);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Drivers Liscence :";
            // 
            // txtCellphone
            // 
            this.txtCellphone.Location = new System.Drawing.Point(110, 97);
            this.txtCellphone.Name = "txtCellphone";
            this.txtCellphone.Size = new System.Drawing.Size(145, 20);
            this.txtCellphone.TabIndex = 13;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(110, 71);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(145, 20);
            this.txtID.TabIndex = 12;
            // 
            // txtLastname
            // 
            this.txtLastname.Location = new System.Drawing.Point(110, 45);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(145, 20);
            this.txtLastname.TabIndex = 11;
            // 
            // txtFirstname
            // 
            this.txtFirstname.Location = new System.Drawing.Point(110, 19);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(145, 20);
            this.txtFirstname.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Firstname :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lastname :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cellphone Number :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ID Number :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtAddressProvince);
            this.groupBox1.Controls.Add(this.txtCityAddress);
            this.groupBox1.Controls.Add(this.txtAddressSuburb);
            this.groupBox1.Controls.Add(this.txtStreetNumber);
            this.groupBox1.Controls.Add(this.txtStreetName);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(286, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(261, 184);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Residential Address ";
            // 
            // txtAddressProvince
            // 
            this.txtAddressProvince.Location = new System.Drawing.Point(69, 123);
            this.txtAddressProvince.Name = "txtAddressProvince";
            this.txtAddressProvince.Size = new System.Drawing.Size(171, 20);
            this.txtAddressProvince.TabIndex = 13;
            // 
            // txtCityAddress
            // 
            this.txtCityAddress.Location = new System.Drawing.Point(69, 97);
            this.txtCityAddress.Name = "txtCityAddress";
            this.txtCityAddress.Size = new System.Drawing.Size(171, 20);
            this.txtCityAddress.TabIndex = 12;
            // 
            // txtAddressSuburb
            // 
            this.txtAddressSuburb.Location = new System.Drawing.Point(69, 71);
            this.txtAddressSuburb.Name = "txtAddressSuburb";
            this.txtAddressSuburb.Size = new System.Drawing.Size(171, 20);
            this.txtAddressSuburb.TabIndex = 11;
            // 
            // txtStreetNumber
            // 
            this.txtStreetNumber.Location = new System.Drawing.Point(69, 45);
            this.txtStreetNumber.Name = "txtStreetNumber";
            this.txtStreetNumber.Size = new System.Drawing.Size(171, 20);
            this.txtStreetNumber.TabIndex = 10;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Location = new System.Drawing.Point(69, 19);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(171, 20);
            this.txtStreetName.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 126);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Province :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "City :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Suburb :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Number :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Street :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(558, 305);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Banking Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtBranchCode);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtAccountNumber);
            this.groupBox3.Controls.Add(this.txtAccountType);
            this.groupBox3.Controls.Add(this.txtBranchName);
            this.groupBox3.Controls.Add(this.txtBankName);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Location = new System.Drawing.Point(36, 65);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(466, 163);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Banking Information";
            // 
            // txtBranchCode
            // 
            this.txtBranchCode.Location = new System.Drawing.Point(159, 129);
            this.txtBranchCode.Name = "txtBranchCode";
            this.txtBranchCode.Size = new System.Drawing.Size(204, 20);
            this.txtBranchCode.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(78, 132);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Branch Code :";
            // 
            // txtAccountNumber
            // 
            this.txtAccountNumber.Location = new System.Drawing.Point(159, 100);
            this.txtAccountNumber.Name = "txtAccountNumber";
            this.txtAccountNumber.Size = new System.Drawing.Size(204, 20);
            this.txtAccountNumber.TabIndex = 13;
            // 
            // txtAccountType
            // 
            this.txtAccountType.Location = new System.Drawing.Point(159, 74);
            this.txtAccountType.Name = "txtAccountType";
            this.txtAccountType.Size = new System.Drawing.Size(204, 20);
            this.txtAccountType.TabIndex = 12;
            // 
            // txtBranchName
            // 
            this.txtBranchName.Location = new System.Drawing.Point(159, 48);
            this.txtBranchName.Name = "txtBranchName";
            this.txtBranchName.Size = new System.Drawing.Size(204, 20);
            this.txtBranchName.TabIndex = 11;
            // 
            // txtBankName
            // 
            this.txtBankName.Location = new System.Drawing.Point(159, 22);
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.Size = new System.Drawing.Size(204, 20);
            this.txtBankName.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(84, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Bank Name :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(75, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Branch Name :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(60, 103);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Account Number :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(73, 77);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Account Type :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(558, 305);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Staff Member Summery";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(258, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Save Staff Memeber";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtSumProvince);
            this.groupBox5.Controls.Add(this.txtSumCity);
            this.groupBox5.Controls.Add(this.txtSumSuburb);
            this.groupBox5.Controls.Add(this.txtSumStreetNum);
            this.groupBox5.Controls.Add(this.txtSumStreet);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Location = new System.Drawing.Point(6, 35);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(261, 155);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Residential Address ";
            // 
            // txtSumProvince
            // 
            this.txtSumProvince.Location = new System.Drawing.Point(69, 123);
            this.txtSumProvince.Name = "txtSumProvince";
            this.txtSumProvince.ReadOnly = true;
            this.txtSumProvince.Size = new System.Drawing.Size(171, 20);
            this.txtSumProvince.TabIndex = 13;
            // 
            // txtSumCity
            // 
            this.txtSumCity.Location = new System.Drawing.Point(69, 97);
            this.txtSumCity.Name = "txtSumCity";
            this.txtSumCity.ReadOnly = true;
            this.txtSumCity.Size = new System.Drawing.Size(171, 20);
            this.txtSumCity.TabIndex = 12;
            // 
            // txtSumSuburb
            // 
            this.txtSumSuburb.Location = new System.Drawing.Point(69, 71);
            this.txtSumSuburb.Name = "txtSumSuburb";
            this.txtSumSuburb.ReadOnly = true;
            this.txtSumSuburb.Size = new System.Drawing.Size(171, 20);
            this.txtSumSuburb.TabIndex = 11;
            // 
            // txtSumStreetNum
            // 
            this.txtSumStreetNum.Location = new System.Drawing.Point(69, 45);
            this.txtSumStreetNum.Name = "txtSumStreetNum";
            this.txtSumStreetNum.ReadOnly = true;
            this.txtSumStreetNum.Size = new System.Drawing.Size(171, 20);
            this.txtSumStreetNum.TabIndex = 10;
            // 
            // txtSumStreet
            // 
            this.txtSumStreet.Location = new System.Drawing.Point(69, 19);
            this.txtSumStreet.Name = "txtSumStreet";
            this.txtSumStreet.ReadOnly = true;
            this.txtSumStreet.Size = new System.Drawing.Size(171, 20);
            this.txtSumStreet.TabIndex = 9;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 126);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "Province :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(33, 100);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 13);
            this.label24.TabIndex = 7;
            this.label24.Text = "City :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 74);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 13);
            this.label25.TabIndex = 6;
            this.label25.Text = "Suburb :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 48);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(50, 13);
            this.label26.TabIndex = 5;
            this.label26.Text = "Number :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(22, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 4;
            this.label27.Text = "Street :";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtSumBranchCode);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.txtSumAccountNumber);
            this.groupBox6.Controls.Add(this.txtSumAccountType);
            this.groupBox6.Controls.Add(this.txtSumBranchname);
            this.groupBox6.Controls.Add(this.txtSumBank);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Location = new System.Drawing.Point(6, 196);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(541, 109);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Banking Information";
            // 
            // txtSumBranchCode
            // 
            this.txtSumBranchCode.Location = new System.Drawing.Point(96, 75);
            this.txtSumBranchCode.Name = "txtSumBranchCode";
            this.txtSumBranchCode.ReadOnly = true;
            this.txtSumBranchCode.Size = new System.Drawing.Size(162, 20);
            this.txtSumBranchCode.TabIndex = 15;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(12, 78);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(75, 13);
            this.label28.TabIndex = 14;
            this.label28.Text = "Branch Code :";
            // 
            // txtSumAccountNumber
            // 
            this.txtSumAccountNumber.Location = new System.Drawing.Point(370, 49);
            this.txtSumAccountNumber.Name = "txtSumAccountNumber";
            this.txtSumAccountNumber.ReadOnly = true;
            this.txtSumAccountNumber.Size = new System.Drawing.Size(165, 20);
            this.txtSumAccountNumber.TabIndex = 13;
            // 
            // txtSumAccountType
            // 
            this.txtSumAccountType.Location = new System.Drawing.Point(96, 48);
            this.txtSumAccountType.Name = "txtSumAccountType";
            this.txtSumAccountType.ReadOnly = true;
            this.txtSumAccountType.Size = new System.Drawing.Size(165, 20);
            this.txtSumAccountType.TabIndex = 12;
            // 
            // txtSumBranchname
            // 
            this.txtSumBranchname.Location = new System.Drawing.Point(370, 22);
            this.txtSumBranchname.Name = "txtSumBranchname";
            this.txtSumBranchname.ReadOnly = true;
            this.txtSumBranchname.Size = new System.Drawing.Size(165, 20);
            this.txtSumBranchname.TabIndex = 11;
            // 
            // txtSumBank
            // 
            this.txtSumBank.Location = new System.Drawing.Point(96, 22);
            this.txtSumBank.Name = "txtSumBank";
            this.txtSumBank.ReadOnly = true;
            this.txtSumBank.Size = new System.Drawing.Size(165, 20);
            this.txtSumBank.TabIndex = 10;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 25);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Bank Name :";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(277, 25);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(78, 13);
            this.label30.TabIndex = 1;
            this.label30.Text = "Branch Name :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(267, 52);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(93, 13);
            this.label31.TabIndex = 3;
            this.label31.Text = "Account Number :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(4, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(80, 13);
            this.label32.TabIndex = 2;
            this.label32.Text = "Account Type :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtSumDepartment);
            this.groupBox4.Controls.Add(this.txtSumDrivers);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.txtSumCellphone);
            this.groupBox4.Controls.Add(this.txtSumID);
            this.groupBox4.Controls.Add(this.txtSumLastname);
            this.groupBox4.Controls.Add(this.txtSumFirstname);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Location = new System.Drawing.Point(286, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(261, 184);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Personal Information";
            // 
            // txtSumDepartment
            // 
            this.txtSumDepartment.Location = new System.Drawing.Point(110, 147);
            this.txtSumDepartment.Name = "txtSumDepartment";
            this.txtSumDepartment.ReadOnly = true;
            this.txtSumDepartment.Size = new System.Drawing.Size(145, 20);
            this.txtSumDepartment.TabIndex = 18;
            // 
            // txtSumDrivers
            // 
            this.txtSumDrivers.Location = new System.Drawing.Point(110, 123);
            this.txtSumDrivers.Name = "txtSumDrivers";
            this.txtSumDrivers.ReadOnly = true;
            this.txtSumDrivers.Size = new System.Drawing.Size(145, 20);
            this.txtSumDrivers.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(33, 150);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 13);
            this.label17.TabIndex = 16;
            this.label17.Text = "Department  :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 126);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 13);
            this.label18.TabIndex = 14;
            this.label18.Text = "Drivers Liscence :";
            // 
            // txtSumCellphone
            // 
            this.txtSumCellphone.Location = new System.Drawing.Point(110, 97);
            this.txtSumCellphone.Name = "txtSumCellphone";
            this.txtSumCellphone.ReadOnly = true;
            this.txtSumCellphone.Size = new System.Drawing.Size(145, 20);
            this.txtSumCellphone.TabIndex = 13;
            // 
            // txtSumID
            // 
            this.txtSumID.Location = new System.Drawing.Point(110, 71);
            this.txtSumID.Name = "txtSumID";
            this.txtSumID.ReadOnly = true;
            this.txtSumID.Size = new System.Drawing.Size(145, 20);
            this.txtSumID.TabIndex = 12;
            // 
            // txtSumLastname
            // 
            this.txtSumLastname.Location = new System.Drawing.Point(110, 45);
            this.txtSumLastname.Name = "txtSumLastname";
            this.txtSumLastname.ReadOnly = true;
            this.txtSumLastname.Size = new System.Drawing.Size(145, 20);
            this.txtSumLastname.TabIndex = 11;
            // 
            // txtSumFirstname
            // 
            this.txtSumFirstname.Location = new System.Drawing.Point(110, 19);
            this.txtSumFirstname.Name = "txtSumFirstname";
            this.txtSumFirstname.ReadOnly = true;
            this.txtSumFirstname.Size = new System.Drawing.Size(145, 20);
            this.txtSumFirstname.TabIndex = 10;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(46, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Firstname :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(45, 48);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "Lastname :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 100);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(100, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Cellphone Number :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 74);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 13);
            this.label22.TabIndex = 2;
            this.label22.Text = "ID Number :";
            // 
            // AddStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 330);
            this.Controls.Add(this.tabControl1);
            this.Name = "AddStaff";
            this.Text = "New Staff Member";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtCellphone;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtLastname;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.TextBox txtAddressProvince;
        private System.Windows.Forms.TextBox txtCityAddress;
        private System.Windows.Forms.TextBox txtAddressSuburb;
        private System.Windows.Forms.TextBox txtStreetNumber;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtAccountNumber;
        private System.Windows.Forms.TextBox txtAccountType;
        private System.Windows.Forms.TextBox txtBranchName;
        private System.Windows.Forms.TextBox txtBankName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtBranchCode;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtSumBranchCode;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtSumAccountNumber;
        private System.Windows.Forms.TextBox txtSumAccountType;
        private System.Windows.Forms.TextBox txtSumBranchname;
        private System.Windows.Forms.TextBox txtSumBank;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSumCellphone;
        private System.Windows.Forms.TextBox txtSumID;
        private System.Windows.Forms.TextBox txtSumLastname;
        private System.Windows.Forms.TextBox txtSumFirstname;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtSumDepartment;
        private System.Windows.Forms.TextBox txtSumDrivers;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtSumProvince;
        private System.Windows.Forms.TextBox txtSumCity;
        private System.Windows.Forms.TextBox txtSumSuburb;
        private System.Windows.Forms.TextBox txtSumStreetNum;
        private System.Windows.Forms.TextBox txtSumStreet;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
    }
}